<?php
// Mulai session
session_start();

// Menggunakan koneksi dari config yang sudah ada
require_once '../config.php'; // Asumsi file config.php berisi kode koneksi Anda

// Cek jika request adalah POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $gelar = $_POST['gelar'];
    $perguruan_tinggi = $_POST['perguruan_tinggi'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Password dari form
    $pekerjaan = $_POST['pekerjaan'];
    $province = $_POST['province']; // Asumsi sudah ada input untuk province
    $regency = $_POST['regency']; // Asumsi sudah ada input untuk regency
    $district = $_POST['district']; // Asumsi sudah ada input untuk district
    $village = $_POST['village']; // Asumsi sudah ada input untuk village

    // Foto upload
    if (isset($_FILES['foto'])) {
        $fotoName = $_FILES['foto']['name'];
        $fotoTmpName = $_FILES['foto']['tmp_name'];
        $fotoSize = $_FILES['foto']['size'];
        $fotoError = $_FILES['foto']['error'];

        if ($fotoError === 0) {
            $fotoExt = pathinfo($fotoName, PATHINFO_EXTENSION);
            $fotoNewName = uniqid('', true) . '.' . $fotoExt;
            $fotoDestination = '../uploads/' . $fotoNewName;

            if (move_uploaded_file($fotoTmpName, $fotoDestination)) {
                // Enkripsi password sebelum menyimpan ke database
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                // Simpan data ke database menggunakan PDO
                $sql = "INSERT INTO mahasiswa (nim, nama, gelar, perguruan_tinggi, pekerjaan, foto, province, regency, district, village, email, password)
                        VALUES (:nim, :nama, :gelar, :perguruan_tinggi, :pekerjaan, :foto, :province, :regency, :district, :village, :email, :password)";
                
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':nim', $nim);
                $stmt->bindParam(':nama', $nama);
                $stmt->bindParam(':gelar', $gelar);
                $stmt->bindParam(':perguruan_tinggi', $perguruan_tinggi);
                $stmt->bindParam(':pekerjaan', $pekerjaan);
                $stmt->bindParam(':foto', $fotoDestination);
                $stmt->bindParam(':province', $province);
                $stmt->bindParam(':regency', $regency);
                $stmt->bindParam(':district', $district);
                $stmt->bindParam(':village', $village);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $hashedPassword);  // Simpan password yang sudah dienkripsi

                if ($stmt->execute()) {
                    // Set session success
                    $_SESSION['success'] = 'Data berhasil disimpan!';
                    header('Location: input_mahasiswa.php'); // Redirect ke halaman yang sama
                    exit();
                } else {
                    $_SESSION['error'] = 'Terjadi kesalahan saat menyimpan data!';
                    header('Location: input_mahasiswa.php'); // Redirect ke halaman yang sama
                    exit();
                }
            } else {
                $_SESSION['error'] = 'Gagal mengupload foto!';
                header('Location: input_mahasiswa.php'); // Redirect ke halaman yang sama
                exit();
            }
        } else {
            $_SESSION['error'] = 'Terjadi kesalahan saat mengupload foto!';
            header('Location: input_mahasiswa.php'); // Redirect ke halaman yang sama
            exit();
        }
    } else {
        $_SESSION['error'] = 'Foto tidak ditemukan!';
        header('Location: input_mahasiswa.php'); // Redirect ke halaman yang sama
        exit();
    }
}

// Cek jika ada session success atau error
if (isset($_SESSION['success'])) {
    echo "<script>
            alert('{$_SESSION['success']}');
          </script>";
    unset($_SESSION['success']); // Hapus session setelah ditampilkan
}

if (isset($_SESSION['error'])) {
    echo "<script>
            alert('{$_SESSION['error']}');
          </script>";
    unset($_SESSION['error']); // Hapus session setelah ditampilkan
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Input Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../assets/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<div id="wrapper">
       <!-- Sidebar -->
       <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SB ADMIN <sup>2</sup></div>
    </a>
    <hr class="sidebar-divider my-0">

    <!-- Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="../index.php">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <!-- Input Mahasiswa -->
    <li class="nav-item active">
        <a class="nav-link" href="input_mahasiswa.php">
            <i class="fas fa-user-plus"></i>
            <span>Input Mahasiswa</span>
        </a>
    </li>

    <!-- List Mahasiswa -->
    <li class="nav-item">
        <a class="nav-link" href="list_mahasiswa.php">
            <i class="fas fa-users"></i>
            <span>Laporan Mahasiswa</span>
        </a>
    </li>

    <!-- Logout -->
    <li class="nav-item">
        <a class="nav-link" href="../logout.php">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </li>
</ul>
        <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div class="container mt-5">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Form Input Mahasiswa</h6>
            </div>
            <div class="card-body">
                <!-- Form Lokasi -->
                <form id="locationForm" class="mb-4">
                    <div class="mb-3">
                        <label for="province" class="form-label">Provinsi</label>
                        <select id="province" class="form-select" required>
                            <option value="">Pilih Provinsi</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="regency" class="form-label">Kabupaten/Kota</label>
                        <select id="regency" class="form-select" required disabled>
                            <option value="">Pilih Kabupaten/Kota</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="district" class="form-label">Kecamatan</label>
                        <select id="district" class="form-select" required disabled>
                            <option value="">Pilih Kecamatan</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="village" class="form-label">Desa/Kelurahan</label>
                        <select id="village" class="form-select" required disabled>
                            <option value="">Pilih Desa/Kelurahan</option>
                        </select>
                    </div>
                </form>

                <!-- Form Input Data Mahasiswa -->
                <form action="input_mahasiswa.php" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="nim">NIM</label>
                        <input type="text" class="form-control" id="nim" name="nim" required>
                    </div>

                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>

                    <div class="form-group">
                        <label for="gelar">Gelar</label>
                        <input type="text" class="form-control" id="gelar" name="gelar" required>
                    </div>

                    <div class="form-group">
                        <label for="perguruan_tinggi">Asal Perguruan Tinggi</label>
                        <input type="text" class="form-control" id="perguruan_tinggi" name="perguruan_tinggi" required>
                    </div>

                    <div class="form-group">
                        <label for="pekerjaan">Pekerjaan</label>
                        <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" required>
                    </div>
                    <div class="form-group">
                        <label for="pekerjaan">Email</label>
                        <input type="text" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="pekerjaan">Password</label>
                        <input type="text" class="form-control" id="password" name="password" required>
                    </div>

                    <div class="form-group">
                        <label for="foto">Foto</label>
                        <input type="file" class="form-control" id="foto" name="foto" accept="image/*" required>
                    </div>

                    <input type="hidden" id="provinceHidden" name="province" value="">
                    <input type="hidden" id="regencyHidden" name="regency" value="">
                    <input type="hidden" id="districtHidden" name="district" value="">
                    <input type="hidden" id="villageHidden" name="village" value="">

                    <button type="submit" class="btn btn-primary btn-block">Simpan</button>
                </form>
            </div>
        </div>
    </div>
<!-- Bootstrap core JavaScript-->
<script src="../assets/vendor/jquery/jquery.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="../assets/js/sb-admin-2.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const provinceSelect = document.getElementById('province');
        const regencySelect = document.getElementById('regency');
        const districtSelect = document.getElementById('district');
        const villageSelect = document.getElementById('village');

        // Fetch Provinces
        fetch('https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json')
            .then(response => response.json())
            .then(provinces => {
                provinces.forEach(province => {
                    const option = document.createElement('option');
                    option.value = province.id;
                    option.textContent = province.name;
                    provinceSelect.appendChild(option);
                });
            });

        // Province Change Event
        provinceSelect.addEventListener('change', function() {
            const provinceId = this.value;
            
            // Reset and disable subsequent dropdowns
            regencySelect.innerHTML = '<option value="">Pilih Kabupaten/Kota</option>';
            districtSelect.innerHTML = '<option value="">Pilih Kecamatan</option>';
            villageSelect.innerHTML = '<option value="">Pilih Desa/Kelurahan</option>';
            
            regencySelect.disabled = true;
            districtSelect.disabled = true;
            villageSelect.disabled = true;

            // Fetch Regencies
            fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/regencies/${provinceId}.json`)
                .then(response => response.json())
                .then(regencies => {
                    regencies.forEach(regency => {
                        const option = document.createElement('option');
                        option.value = regency.id;
                        option.textContent = regency.name;
                        regencySelect.appendChild(option);
                    });
                    regencySelect.disabled = false;
                });
        });

        // Regency Change Event
        regencySelect.addEventListener('change', function() {
            const regencyId = this.value;
            
            // Reset and disable subsequent dropdowns
            districtSelect.innerHTML = '<option value="">Pilih Kecamatan</option>';
            villageSelect.innerHTML = '<option value="">Pilih Desa/Kelurahan</option>';
            
            districtSelect.disabled = true;
            villageSelect.disabled = true;

            // Fetch Districts
            fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/districts/${regencyId}.json`)
                .then(response => response.json())
                .then(districts => {
                    districts.forEach(district => {
                        const option = document.createElement('option');
                        option.value = district.id;
                        option.textContent = district.name;
                        districtSelect.appendChild(option);
                    });
                    districtSelect.disabled = false;
                });
        });

        // District Change Event
        districtSelect.addEventListener('change', function() {
            const districtId = this.value;
            
            // Reset village dropdown
            villageSelect.innerHTML = '<option value="">Pilih Desa/Kelurahan</option>';
            villageSelect.disabled = true;

            // Fetch Villages
            fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/villages/${districtId}.json`)
                .then(response => response.json())
                .then(villages => {
                    villages.forEach(village => {
                        const option = document.createElement('option');
                        option.value = village.id;
                        option.textContent = village.name;
                        villageSelect.appendChild(option);
                    });
                    villageSelect.disabled = false;
                });
        });
        // Setelah pengguna memilih lokasi
document.getElementById('province').addEventListener('change', function () {
    document.getElementById('provinceHidden').value = this.value;
});
document.getElementById('regency').addEventListener('change', function () {
    document.getElementById('regencyHidden').value = this.value;
});
document.getElementById('district').addEventListener('change', function () {
    document.getElementById('districtHidden').value = this.value;
});
document.getElementById('village').addEventListener('change', function () {
    document.getElementById('villageHidden').value = this.value;
});

    });
    </script>
</body>
</html>