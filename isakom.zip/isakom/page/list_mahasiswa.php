<?php
// Include config.php untuk pengaturan database atau koneksi lainnya
include('../config.php');

// Fungsi untuk mengambil nama wilayah dari API
function getLocationName($id, $type) {
    $url = "https://www.emsifa.com/api-wilayah-indonesia/api/{$type}/{$id}.json";
    
    // Get JSON response
    $json = @file_get_contents($url);
    
    // Check if the response is valid
    if ($json === false) {
        return "Unknown {$type}"; // Return a default value if the request fails
    }

    // Decode the JSON response
    $data = json_decode($json, true);
    
    // Return the location name if it exists, otherwise return the ID
    return $data['name'] ?? $id;
}

// Proses Hapus
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['nim'])) {
    $nim = $_GET['nim'];
    try {
        $query = "DELETE FROM mahasiswa WHERE nim = :nim";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':nim', $nim);
        $stmt->execute();
        
        // Redirect dengan pesan sukses
        header("Location: list_mahasiswa.php?status=success&message=Mahasiswa berhasil dihapus");
        exit();
    } catch (PDOException $e) {
        // Redirect dengan pesan error
        header("Location: list_mahasiswa.php?status=error&message=" . urlencode($e->getMessage()));
        exit();
    }
}

// Proses Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update') {
    try {
        $query = "UPDATE mahasiswa SET 
                    nama = :nama, 
                    province = :province, 
                    regency = :regency, 
                    district = :district, 
                    village = :village, 
                    gelar = :gelar, 
                    perguruan_tinggi = :perguruan_tinggi, 
                    pekerjaan = :pekerjaan 
                  WHERE nim = :nim";
        
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':nim', $_POST['nim']);
        $stmt->bindParam(':nama', $_POST['nama']);
        $stmt->bindParam(':province', $_POST['province']);
        $stmt->bindParam(':regency', $_POST['regency']);
        $stmt->bindParam(':district', $_POST['district']);
        $stmt->bindParam(':village', $_POST['village']);
        $stmt->bindParam(':gelar', $_POST['gelar']);
        $stmt->bindParam(':perguruan_tinggi', $_POST['perguruan_tinggi']);
        $stmt->bindParam(':pekerjaan', $_POST['pekerjaan']);
        
        $stmt->execute();
        
        // Redirect dengan pesan sukses
        header("Location: list_mahasiswa.php?status=success&message=Mahasiswa berhasil diupdate");
        exit();
    } catch (PDOException $e) {
        // Redirect dengan pesan error
        header("Location: list_mahasiswa.php?status=error&message=" . urlencode($e->getMessage()));
        exit();
    }
}

// Ambil data mahasiswa dengan menggunakan PDO
try {
    // Query untuk mengambil data mahasiswa
    $query = "SELECT * FROM mahasiswa";
    
    // Menyiapkan statement
    $stmt = $pdo->prepare($query);
    
    // Eksekusi query
    $stmt->execute();
    
    // Mengambil hasilnya dalam bentuk array asosiatif
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>List Data Mahasiswa</title>

    <!-- Custom fonts for this template-->
    <link href="../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400, 400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../assets/css/sb-admin-2.min.css" rel="stylesheet">
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- DataTables CSS -->
        <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css" rel="stylesheet">

<!-- SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body id="page-top">
<div id="wrapper">
   <!-- Sidebar -->
   <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
<!-- Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
    <div class="sidebar-brand-icon rotate-n-15">
        <i class="fas fa-laugh-wink"></i>
    </div>
    <div class="sidebar-brand-text mx-3">SB ADMIN <sup>2</sup></div>
</a>
<hr class="sidebar-divider my-0">

<!-- Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="../index.php">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
    </a>
</li>

<!-- Input Mahasiswa -->
<li class="nav-item active">
    <a class="nav-link" href="input_mahasiswa.php">
        <i class="fas fa-user-plus"></i>
        <span>Input Mahasiswa</span>
    </a>
</li>

<!-- List Mahasiswa -->
<li class="nav-item">
    <a class="nav-link" href="list_mahasiswa.php">
        <i class="fas fa-users"></i>
        <span>Laporan Mahasiswa</span>
    </a>
</li>

<!-- Logout -->
<li class="nav-item">
    <a class="nav-link" href="../logout.php">
        <i class="fas fa-sign-out-alt"></i>
        <span>Logout</span>
    </a>
</li>
</ul>
    <!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
    <div id="content">
        <div class="container mt-3">
            <!-- Pesan Status -->
            <?php if(isset($_GET['status'])): ?>
                <div class="alert alert-<?= $_GET['status'] == 'success' ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($_GET['message']) ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

</head>
<body>
<div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">List Data Mahasiswa</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Provinsi</th>
                    <th>Kabupaten/Kota</th>
                    <th>Kecamatan</th>
                    <th>Desa</th>
                    <th>Gelar</th>
                    <th>Perguruan Tinggi</th>
                    <th>Pekerjaan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $mahasiswa): ?>
                <tr>
                    <td><?php echo $mahasiswa['nim']; ?></td>
                    <td><?php echo $mahasiswa['nama']; ?></td>
                    <td><?php echo getLocationName($mahasiswa['province'], 'province'); ?></td>
                    <td><?php echo getLocationName($mahasiswa['regency'], 'regency'); ?></td>
                    <td><?php echo getLocationName($mahasiswa['district'], 'district'); ?></td>
                    <td><?php echo getLocationName($mahasiswa['village'], 'village'); ?></td>
                    <td><?php echo $mahasiswa['gelar']; ?></td>
                    <td><?php echo $mahasiswa['perguruan_tinggi']; ?></td>
                    <td><?php echo $mahasiswa['pekerjaan']; ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#editModal" 
                                data-nim="<?php echo $mahasiswa['nim']; ?>" 
                                data-nama="<?php echo $mahasiswa['nama']; ?>" 
                                data-province="<?php echo $mahasiswa['province']; ?>" 
                                data-regency="<?php echo $mahasiswa['regency']; ?>" 
                                data-district="<?php echo $mahasiswa['district']; ?>" 
                                data-village="<?php echo $mahasiswa['village']; ?>" 
                                data-gelar="<?php echo $mahasiswa['gelar']; ?>" 
                                data-perguruan="<?php echo $mahasiswa['perguruan_tinggi']; ?>" 
                                data-pekerjaan="<?php echo $mahasiswa['pekerjaan']; ?>">
                            Edit
                        </button>
                        <a href="?action=delete&nim=<?php echo $mahasiswa['nim']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
        // Mengisi data ke modal edit
        $('#editModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
            modal.find('#edit-nim').val(button.data('nim'));
            modal.find('#edit-nama').val(button.data('nama'));
            modal.find('#edit-province').val(button.data('province'));
            modal.find('#edit-regency').val(button.data('regency'));
            modal.find('#edit-district').val(button.data('district'));
            modal.find('#edit-village').val(button.data('village'));
            modal.find('#edit-gelar').val(button.data('gelar'));
            modal.find('#edit-perguruan-tinggi').val(button.data('perguruan'));
            modal.find('#edit-pekerjaan').val(button.data('pekerjaan'));
        });
    </script>

    <!-- Modal Edit -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Mahasiswa</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="editForm" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="nim" id="edit-nim">
                        
                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" class="form-control" name="nama" id="edit-nama" required>
                        </div>

                        <div class="form-group">
                            <label>Provinsi</label>
                            <select class="form-control" name="province" id="edit-province" required>
                                <option value="">Pilih Provinsi</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Kabupaten/Kota</label>
                            <select class="form-control" name="regency" id="edit-regency" required disabled>
                                <option value="">Pilih Kabupaten/Kota</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Kecamatan</label>
                            <select class="form-control" name="district" id="edit-district" required disabled>
                                <option value="">Pilih Kecamatan</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Desa</label>
                            <select class="form-control" name="village" id="edit-village" required disabled>
                                <option value="">Pilih Desa</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Gelar</label>
                            <input type="text" class="form-control" name="gelar" id="edit-gelar" required>
                        </div>

                        <div class="form-group">
                            <label>Perguruan Tinggi</label>
                            <input type="text" class="form-control" name="perguruan_tinggi" id="edit-perguruan-tinggi" required>
                        </div>

                        <div class="form-group">
                            <label>Pekerjaan</label>
                            <input type="text" class="form-control" name="pekerjaan" id="edit-pekerjaan" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Mengambil data provinsi saat halaman dimuat
            $.get('https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json', function(data) {
                const provinceSelect = $('#edit-province');
                provinceSelect.empty();
                provinceSelect.append('<option value="">Pilih Provinsi</option>');
                $.each(data, function(index, province) {
                    provinceSelect.append('<option value="' + province.id + '">' + province.name + '</option>');
                });
            });

            // Mengambil data kota/kabupaten berdasarkan provinsi yang dipilih
            $('#edit-province').on('change', function() {
                const provinceId = $(this).val();
                if (provinceId) {
                    $.get('https://www.emsifa.com/api-wilayah-indonesia/api/regencies/' + provinceId + '.json', function(data) {
                        const regencySelect = $('#edit-regency');
                        regencySelect.empty().prop('disabled', false);
                        regencySelect.append('<option value="">Pilih Kabupaten/Kota</option>');
                        $.each(data, function(index, regency) {
                            regencySelect.append('<option value="' + regency.id + '">' + regency.name + '</option>');
                        });
                    });
                } else {
                    $('#edit-regency').empty().prop('disabled', true);
                    $('#edit-district').empty().prop('disabled', true);
                    $('#edit-village').empty().prop('disabled', true);
                }
            });

            // Mengambil data kecamatan berdasarkan kota/kabupaten yang dipilih
            $('#edit-regency').on('change', function() {
                const regencyId = $(this).val();
                if (regencyId) {
                    $.get('https://www.emsifa.com/api-wilayah-indonesia/api/districts/' + regencyId + '.json', function(data) {
                        const districtSelect = $('#edit-district');
 districtSelect.empty().prop('disabled', false);
                        districtSelect.append('<option value="">Pilih Kecamatan</option>');
                        $.each(data, function(index, district) {
                            districtSelect.append('<option value="' + district.id + '">' + district.name + '</option>');
                        });
                    });
                } else {
                    $('#edit-district').empty().prop('disabled', true);
                    $('#edit-village').empty().prop('disabled', true);
                }
            });

            // Mengambil data kelurahan berdasarkan kecamatan yang dipilih
            $('#edit-district').on('change', function() {
                const districtId = $(this).val();
                if (districtId) {
                    $.get('https://www.emsifa.com/api-wilayah-indonesia/api/villages/' + districtId + '.json', function(data) {
                        const villageSelect = $('#edit-village');
                        villageSelect.empty().prop('disabled', false);
                        villageSelect.append('<option value="">Pilih Desa</option>');
                        $.each(data, function(index, village) {
                            villageSelect.append('<option value="' + village.id + '">' + village.name + '</option>');
                        });
                    });
                } else {
                    $('#edit-village').empty().prop('disabled', true);
                }
            });
        });
    </script>
</body>
</html>