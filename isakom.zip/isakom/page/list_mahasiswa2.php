<?php
// Include config.php untuk pengaturan database atau koneksi lainnya
include('../config.php');

// Fungsi untuk mengambil nama wilayah dari API
function getLocationName($id, $type) {
    $url = "https://www.emsifa.com/api-wilayah-indonesia/api/{$type}/{$id}.json";
    
    // Get JSON response
    $json = @file_get_contents($url);
    
    // Check if the response is valid
    if ($json === false) {
        return "Unknown {$type}"; // Return a default value if the request fails
    }

    // Decode the JSON response
    $data = json_decode($json, true);
    
    // Return the location name if it exists, otherwise return the ID
    return $data['name'] ?? $id;
}

// Proses Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update') {
    try {
        $query = "UPDATE mahasiswa SET 
                    nama = :nama, 
                    province = :province, 
                    regency = :regency, 
                    district = :district, 
                    village = :village, 
                    gelar = :gelar, 
                    perguruan_tinggi = :perguruan_tinggi, 
                    pekerjaan = :pekerjaan 
                  WHERE nim = :nim";
        
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':nim', $_POST['nim']);
        $stmt->bindParam(':nama', $_POST['nama']);
        $stmt->bindParam(':province', $_POST['province']);
        $stmt->bindParam(':regency', $_POST['regency']);
        $stmt->bindParam(':district', $_POST['district']);
        $stmt->bindParam(':village', $_POST['village']);
        $stmt->bindParam(':gelar', $_POST['gelar']);
        $stmt->bindParam(':perguruan_tinggi', $_POST['perguruan_tinggi']);
        $stmt->bindParam(':pekerjaan', $_POST['pekerjaan']);
        
        $stmt->execute();
        
        // Redirect dengan pesan sukses
        header("Location: list_mahasiswa.php?status=success&message=Mahasiswa berhasil diupdate");
        exit();
    } catch (PDOException $e) {
        // Redirect dengan pesan error
       
        exit();
    }
}

// Ambil data mahasiswa dengan menggunakan PDO
try {
    // Query untuk mengambil data mahasiswa
    $query = "SELECT * FROM mahasiswa";
    
    // Menyiapkan statement
    $stmt = $pdo->prepare($query);
    
    // Eksekusi query
    $stmt->execute();
    
    // Mengambil hasilnya dalam bentuk array asosiatif
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>List Data Mahasiswa</title>

    <!-- Custom fonts for this template-->
    <link href="../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../assets/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!-- SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body id="page-top">
<div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">SB MHS <sup>2</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="../index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <!-- Other Links -->
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Profil Mahasiswa</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="list_mahasiswa2.php">
                    <i class="fas fa-fw fa-list"></i>
                    <span>List Mahasiswa</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
        <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <div class="container mt-3">
                <!-- Pesan Status -->
                <?php if(isset($_GET['status'])): ?>
                    <div class="alert alert-<?= $_GET['status'] == 'success' ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($_GET['message']) ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <!-- Card Start -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">List Data Mahasiswa</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIM</th>
                                        <th>Nama</th>
                                        <th>Provinsi</th>
                                        <th>Kabupaten/Kota</th>
                                        <th>Kecamatan</th>
                                        <th>Desa</th>
                                        <th>Gelar</th>
                                        <th>Perguruan Tinggi</th>
                                        <th>Pekerjaan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Menampilkan data mahasiswa
                                    $no = 1;
                                    foreach ($data as $row) {
                                        // Konversi kode wilayah menjadi nama
                                        $provinceName = getLocationName($row['province'], 'province');
                                        $regencyName = getLocationName($row['regency'], 'regency');
                                        $districtName = getLocationName($row['district'], 'district');
                                        $villageName = getLocationName($row['village'], 'village');

                                        echo "<tr>
                                                <td>{$no}</td>
                                                <td>{$row['nim']}</td>
                                                <td>{$row['nama']}</td>
                                                <td>{$provinceName}</td>
                                                <td>{$regencyName}</td>
                                                <td>{$districtName}</td>
                                                <td>{$villageName}</td>
                                                <td>{$row['gelar']}</td>
                                                <td>{$row['perguruan_tinggi']}</td>
                                                <td>{$row['pekerjaan']}</td>

                                                </td>
                                              </tr>";
                                        $no++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Card End -->
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Mahasiswa</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editForm" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="nim" id="edit-nim">
                    
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control" name="nama" id="edit-nama" required>
                    </div>

                    <div class="form-group">
                        <label>Provinsi</label>
                        <select class="form-control" name="province" id="edit-province" required>
                            <option value="">Pilih Provinsi</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Kabupaten/Kota</label>
                        <select class="form-control" name="regency" id="edit-regency" required disabled>
                            <option value="">Pilih Kabupaten/Kota</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Kecamatan</label>
                        <select class="form-control" name="district" id="edit-district" required disabled>
                            <option value="">Pilih Kecamatan</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Desa</label>
                        <select class="form-control" name="village" id="edit-village" required disabled>
                            <option value="">Pilih Desa</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Gelar</label>
                        <input type="text" class="form-control" name="gelar" id="edit-gelar" required>
                    </div>

                    <div class="form-group">
                        <label>Perguruan Tinggi</label>
                        <input type="text" class="form-control" name="perguruan_tinggi" id="edit-perguruan-tinggi" required>
                    </div>

                    <div class="form-group">
                        <label>Pekerjaan</label>
                        <input type="text" class="form-control" name="pekerjaan" id="edit-pekerjaan" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../assets/vendor/jquery/jquery.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="../assets/js/sb-admin-2.min.js"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>
<script>
    // Inisialisasi DataTable
    $(document).ready(function() {
        $('#dataTable').DataTable();

        // Mengambil data untuk form modal edit
        $('.edit-btn').on('click', function() {
            const nim = $(this).data('nim');
            const nama = $(this).data('nama');
            const province = $(this).data('province');
            const regency = $(this).data('regency');
            const district = $(this).data('district');
            const village = $(this).data('village');
            const gelar = $(this).data('gelar');
            const perguruan_tinggi = $(this).data('perguruan-tinggi');
            const pekerjaan = $(this).data('pekerjaan');

            // Isi data di modal edit
            $('#edit-nim').val(nim);
            $('#edit-nama').val(nama);
            $('#edit-province').val(province).trigger('change');
            $('#edit-regency').val(regency).prop('disabled', false);
            $('#edit-district').val(district).prop('disabled', false);
            $('#edit-village').val(village).prop('disabled', false);
            $('#edit-gelar').val(gelar);
            $('#edit-perguruan-tinggi').val(perguruan_tinggi);
            $('#edit-pekerjaan').val(pekerjaan);

            // Tampilkan modal edit
            $('#editModal').modal('show');
        });

        // Menghapus mahasiswa dengan konfirmasi SweetAlert
        $('.delete-btn').on('click', function() {
            const nim = $(this).data('nim');

            // Konfirmasi sebelum hapus
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data mahasiswa ini akan dihapus!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Redirect untuk menghapus data
                    window.location.href = 'list_mahasiswa.php?action=delete&nim=' + nim;
                }
            });
        });

        // Update data wilayah dinamis (provinsi, kabupaten, kecamatan, desa)
        $('#edit-province').on('change', function() {
            const provinceId = $(this).val();
            if (provinceId) {
                $.get('https://www.emsifa.com/api-wilayah-indonesia/api/regencies/' + provinceId + '.json', function(data) {
                    const regencySelect = $('#edit-regency');
                    regencySelect.empty();
                    regencySelect.append('<option value="">Pilih Kabupaten/Kota</option>');
                    $.each(data, function(index, regency) {
                        regencySelect.append('<option value="' + regency.id + '">' + regency.name + '</option>');
                    });
                    regencySelect.prop('disabled', false);
                });
            }
        });

        $('#edit-regency').on('change', function() {
            const regencyId = $(this).val();
            if (regencyId) {
                $.get('https://www.emsifa.com/api-wilayah-indonesia/api/districts/' + regencyId + '.json', function(data) {
                    const districtSelect = $('#edit-district');
                    districtSelect.empty();
                    districtSelect.append('<option value="">Pilih Kecamatan</option>');
                    $.each(data, function(index, district) {
                        districtSelect.append('<option value="' + district.id + '">' + district.name + '</option>');
                    });
                    districtSelect.prop('disabled', false);
                });
            }
        });

        $('#edit-district').on('change', function() {
            const districtId = $(this).val();
            if (districtId) {
                $.get('https://www.emsifa.com/api-wilayah-indonesia/api/villages/' + districtId + '.json', function(data) {
                    const villageSelect = $('#edit-village');
                    villageSelect.empty();
                    villageSelect.append('<option value="">Pilih Desa</option>');
                    $.each(data, function(index, village) {
                        villageSelect.append('<option value="' + village.id + '">' + village.name + '</option>');
                    });
                    villageSelect.prop('disabled', false);
                });
            }
        });
    });
</script>

                                </body>
                                </html>