<?php
// Include config.php untuk pengaturan database atau koneksi lainnya
include('../config.php');
session_start();

// Fungsi untuk mengambil nama wilayah dari API
function getLocationName($id, $type) {
    $url = "https://www.emsifa.com/api-wilayah-indonesia/api/{$type}/{$id}.json";
    $json = @file_get_contents($url);
    if ($json === false) {
        return "Unknown {$type}";
    }
    $data = json_decode($json, true);
    return $data['name'] ?? $id;
}

// Ambil data mahasiswa berdasarkan email
$email = $_SESSION['user_email'];
try {
    $query = "SELECT * FROM mahasiswa WHERE email = :email";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

if (!$data) {
    die("Mahasiswa dengan email {$email} tidak ditemukan.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Profil Mahasiswa</title>

    <!-- Custom fonts and styles for this template-->
    <link href="../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">
    <link href="../assets/css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">

<div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3">SB MHS <sup>2</sup></div>
        </a>
        <hr class="sidebar-divider my-0">
        <li class="nav-item active">
            <a class="nav-link" href="../index.php">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="profile.php">
                <i class="fas fa-fw fa-user"></i>
                <span>Profil Mahasiswa</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="list_mahasiswa2.php">
                <i class="fas fa-fw fa-list"></i>
                <span>List Mahasiswa</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-fw fa-sign-out-alt"></i>
                <span>Logout</span></a>
        </li>
    </ul>
    <!-- End of Sidebar -->

    <div class="container-fluid">
        <!-- Profil Mahasiswa -->
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-center">
                <div class="text-center">
                    <img class="img-profile rounded-circle mb-3" 
                         src="<?= htmlspecialchars($data['foto']) ?>" 
                         alt="Foto Profil" 
                         style="width: 150px; height: 150px; object-fit: cover;">
                    <h1 class="h4 text-gray-900 mb-0"> <?= htmlspecialchars($data['nama']) ?> </h1>
                </div>
            </div>
            <div class="card-body">
                <h5 class="text-primary">Informasi Dasar</h5>
                <p><strong>Nama Lengkap:</strong> <?= htmlspecialchars($data['nama']) ?></p>
                <p><strong>NIM:</strong> <?= htmlspecialchars($data['nim']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($data['email']) ?></p>
                <p><strong>Kelurahan:</strong> <?= getLocationName($data['village'], 'village') ?></p>
                <p><strong>Kecamatan:</strong> <?= getLocationName($data['district'], 'district') ?></p>
                <p><strong>Kabupaten/Kota:</strong> <?= getLocationName($data['regency'], 'regency') ?></p>
                <p><strong>Provinsi:</strong> <?= getLocationName($data['province'], 'province') ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="../assets/vendor/jquery/jquery.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="../assets/vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="../assets/js/sb-admin-2.min.js"></script>
</body>
</html>
