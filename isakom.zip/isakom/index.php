<?php
session_start();
include 'config.php';

// Jika pengguna sudah login, arahkan ke dashboard sesuai peran
if (isset($_SESSION['user_role'])) {
    if ($_SESSION['user_role'] === 'admin') {
        header('Location: page/dashboard.php');
        exit();
    } elseif ($_SESSION['user_role'] === 'mahasiswa') {
        header('Location: page/dashboard2.php');
        exit();
    }
}

// Jika belum login, arahkan ke halaman login
header('Location: page/login.php');
exit();
