<?php
session_start();

// Menghapus semua session yang aktif
session_unset();

// Menghancurkan session
session_destroy();

// Mengarahkan pengguna kembali ke halaman login
header("Location: index.php");
exit();
?>
