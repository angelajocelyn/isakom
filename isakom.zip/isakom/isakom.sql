-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2024 at 08:54 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `isakom`
--

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE `komentar` (
  `id` int(11) NOT NULL,
  `nama_komentator` varchar(255) NOT NULL,
  `komentar` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `komentar`
--

INSERT INTO `komentar` (`id`, `nama_komentator`, `komentar`, `tanggal`) VALUES
(1, 'Angela', 'Bagus', '2024-12-19 03:55:49'),
(2, 'Jocelyn', 'Keren', '2024-12-19 04:26:30');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `nim` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `gelar` varchar(255) NOT NULL,
  `perguruan_tinggi` varchar(255) NOT NULL,
  `pekerjaan` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `regency` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `village` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` varchar(255) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `nim`, `nama`, `gelar`, `perguruan_tinggi`, `pekerjaan`, `foto`, `province`, `regency`, `district`, `village`, `email`, `password`, `created_at`, `deleted_at`) VALUES
(9, '2257201047', 'Angela', 'S1', 'IBTPI Pelita', 'Freelance', '../uploads/6762b905394b71.54703599.jpg', '14', '1471', '1471021', '1471021002', 'angela@gmail.com', '$2y$10$tGYyXyLzXDSC5WlEwlxE3e7QdmVrd64NBCCPd/XTN2pqtV86LxQiy', '2024-12-18 11:59:01', 'N'),
(10, '12345678', 'Jocelyn', 'S2', 'Politeknik Caltex', 'Software Engineer', '../uploads/6762ba4501a508.51383159.jpg', '14', '1471', '1471070', '1471070005', 'jocelyn@gmail.com', '$2y$10$QMg3w4iwQx9cfuVEEqpnReGJpZI02aWTJ6mmvUco68K/uHlsLBh72', '2024-12-18 12:04:21', 'N'),
(11, '225723457890', 'Rudi', 'S1', 'UNILAK', 'Web Developer', '../uploads/6763956d1d3179.11434386.jpg', '14', '1471', '1471080', '1471080007', 'rudi@gmail.com', '$2y$10$pZ9VVs1gpKehLmHJg8TpteBgqf5QEj.IeEIYhmv729kFGrNGVImhG', '2024-12-19 03:39:25', 'N'),
(12, '225723457855', 'Lucy', 'S1', 'IBTPI Pelita', 'Freelance', '../uploads/6763a362efe9a0.72742271.jpg', '14', '1471', '1471021', '1471021005', 'lucy@gmail.com', '$2y$10$LxDoVrcHZXbciwnyZ76gHuDDmb6Aek4ss2naNM7lh9PX31fYrPeFa', '2024-12-19 04:38:59', 'N'),
(13, '23434234', 'dfdsf', 'sdfda', 'asdf', 'asdf', '../uploads/67653a388deb42.09605930.png', '14', '1471', '1471080', '1471080012', 'annn@gmail.com', '$2y$10$7pZp2b37/JjF6CexaM/ehOR/1vtS4nYEg6xtnlGpFsnaPlm9dY4gi', '2024-12-20 09:34:48', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `peran` varchar(255) NOT NULL,
  `deleted_at` char(1) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `email`, `password`, `peran`, `deleted_at`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$rXnC5Hlf3e9agItNiF2AKea4hgqac2PXRdkx.EKro1NjLDOkx6Xwm', 'admin', 'N'),
(3, 'angela', 'angela@gmail.com', '$2y$10$HvKbGnHVvwAAd6KvQ7WmsebUeeupGbiHETYspi4RvynrmZOrkHe3q', 'mahasiswa', 'N');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `komentar`
--
ALTER TABLE `komentar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `komentar`
--
ALTER TABLE `komentar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
