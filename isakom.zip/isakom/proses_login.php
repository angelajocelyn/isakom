<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Cek di tabel user terlebih dahulu
    $stmt = $pdo->prepare("SELECT * FROM user WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Jika email ditemukan di tabel user, verifikasi password
        if (password_verify($password, $user['password'])) {
            // Menyimpan informasi user ke sesi
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['peran'];  // Role pengguna (admin atau lainnya)
            $_SESSION['user_email'] = $user['email'];  // Menyimpan email ke sesi

            // Arahkan berdasarkan role pengguna
            if ($user['peran'] === 'admin') {
                header("Location: page/dashboard.php");  // Arahkan ke dashboard jika admin
            } elseif ($user['peran'] === 'mahasiswa') {
                header("Location: page/dashboard2.php");  // Arahkan ke mahasiswa jika peran mahasiswa
            } else {
                echo "Peran tidak dikenali.";
            }
            exit();
        } else {
            // Jika password tidak cocok
            $_SESSION['error_message'] = "Email atau password salah.";
            header("Location: page/login.php");  // Arahkan kembali ke halaman login
            exit();
        }
    } else {
        // Jika email tidak ditemukan di tabel user, cek di tabel mahasiswa
        $stmt = $pdo->prepare("SELECT * FROM mahasiswa WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $mahasiswa = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($mahasiswa) {
            // Jika email ditemukan di tabel mahasiswa, simpan email ke sesi
            $_SESSION['user_id'] = $mahasiswa['id']; // Simpan ID mahasiswa ke sesi
            $_SESSION['user_email'] = $mahasiswa['email'];  // Simpan email ke sesi
            header("Location: page/dashboard2.php");  // Arahkan ke mahasiswa.php
            exit();
        } else {
            // Jika email tidak ditemukan di kedua tabel
            $_SESSION['error_message'] = "Email tidak ditemukan di sistem.";
            header("Location: page/login.php");  // Arahkan kembali ke halaman login
            exit();
        }
    }
}
?>
